.. test documentation master file, created by
   sphinx-quickstart on Mon Dec  7 15:41:34 2020.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to DataKund's documentation!
====================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   intro
   installation
   functions
   otherfunctions