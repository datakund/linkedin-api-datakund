Functions
**************************************************

``datakund`` provides following functions for linkedin:-

.. toctree::
   :maxdepth: 2

   login