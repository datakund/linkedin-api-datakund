Installation/Usage:
*******************
You can find this package on Pypi (see `here <https://pypi.org/project/datakund/>`_).

Command to install :- ``pip install datakund``

Import datakund
**************************************************
.. code-block:: python

	from datakund.datakund import *

Creating Object
**************************************************
.. code-block:: python
	
	obj=datakund()
	linkedin=obj.linkedin()
	
It will return the object which you can further use to call linkedin functions and opens a automated browser