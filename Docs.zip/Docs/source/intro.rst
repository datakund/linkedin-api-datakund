Introduction
***************************

``datakund`` is an automation library which can be used to automate tasks like sending mails,scraping data,auto checkout and many more. You can download the source code from here(see `here <https://github.com/testdatakund/linkedin>`_)

It uses selenium to automate the things. You can use its inbuilt functions like ``linkedin_follow``, ``linkedin_login`` etc. in a very easy way.
